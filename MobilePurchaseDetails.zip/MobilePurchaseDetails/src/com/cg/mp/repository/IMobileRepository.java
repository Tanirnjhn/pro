package com.cg.mp.repository;

import java.time.LocalDate;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;

public interface IMobileRepository {
	 
	Customer add(Customer cus);
	Mobile showMobDetails(int mobId);
	Mobile findByPrice(float mobprice1);
	void updateQuantity(int mobId);
}
