package com.cg.mp.repository;

import java.util.HashMap;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;

public class MobileRepoImplements implements IMobileRepository {
	Map<Integer,Mobile> hm=new HashMap();
	Map<Integer,Customer>hc=new HashMap<>();
    Mobile m=new Mobile();
    
	 MobileRepoImplements(Map<Integer, Mobile> hm) {

	super();
	this.hm=hm;
	}

	@Override
	public Customer add(Customer cus) {
       
		hc.put(cus.getMobileId(),cus);
       return cus;
	}

	@Override
	public Mobile showMobDetails(int mobId) {
 
		return null;
	}

	@Override
	public Mobile findByPrice(int Price1) {
		for (Mobile find : hm.values())  
           if(find.getMobPrice()>Price1 || find.getMobPrice()<Price1)
        	   return m;
	}

	@Override
	public void updateQuantity(int mobId) {

		if()
	}

	@Override
	public Mobile findByPrice(float mobprice1) {

		return null;
	}

}
