package com.cg.mp.service;

import java.time.LocalDate;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;
import com.cg.mp.repository.IMobileRepository;
import com.cg.mp.repository.MobileRepoImplements;
import com.pg.mp.exception.InavlidCustNameException;
import com.pg.mp.exception.InvalidMailException;
import com.pg.mp.exception.InvalidMobException;
import com.pg.mp.exception.InvalidPhoneException;

public class MobileImplements implements IMobile{
    Mobile mob=new Mobile();
	private IMobileRepository repo;
	public MobileImplements(Map<Integer,Mobile> hm)
	{
	    repo=new MobileRepoImplements(hm);
	}
	public MobileImplements(IMobileRepository repo)
	{
		super();
		this.repo=repo;
	}
	public MobileImplements()
	{
		
	}
	
	
	@Override
	public Customer insert(String custName, String custMail, int purchaseId, String phoneNum, LocalDate date,int mobileId) {
		Customer cus=null;
		cus=new Customer(custName,custMail,purchaseId,phoneNum,date,mobileId);
		if(IsVaildId(mobileId) && IsValidCustName(custName) && IsValidMail(custMail) && IsValidPhone(phoneNum)) 
              repo.add(cus);
		return cus;
	}

	@Override
	public Mobile view(int mobileId)
	{
		if(IsValidId(mobileId))
	      repo.showMobDetails(int mobileId);
		return mob;
	}

	@Override
	public Mobile search(float mobprice1)
	{
        repo.findByPrice(mobprice1);
       return mob;
	}
	
	boolean IsVaildId(int mobId)
	{
		if(!(mobId).matches("[0-9]{4}"))
            throw new InvalidMobException("Mobile Id should Be greater than 4 digit");
		return true;
	}
    boolean IsValidCustName(String custName)
    {
    	if(!custName.matches("[A-Z][a-zA-Z]{1,20}"))
    			throw new InavlidCustNameException("Customer Name Should be of maximum length 20 only and first leeter should be capital ");
    	return true;
    }
    boolean IsValidMail(String mail)
    {
        if(!(mail.matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$")))
        	throw new InvalidMailException("Invalid Mail Id");
        return true;
    }
    boolean IsValidPhone(String phoneNum)
    {
    	if(!phoneNum.matches("[1-9][0-9]{9}"))
    		throw new InvalidPhoneException("Phone number Should be of 10 digits only");
    	return true;
    	
    }
    
}
