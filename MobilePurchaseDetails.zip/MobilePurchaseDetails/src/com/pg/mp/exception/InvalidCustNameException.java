package com.pg.mp.exception;


public class InavlidCustNameException extends RuntimeException {
	public InavlidCustNameException(String msg)
	{
		super(msg);
	}

}

