package com.pg.mp.exception;

public class InvalidMailException extends RuntimeException {
public InvalidMailException(String msg)
	{
		super(msg);
	}

}
