package com.pg.mp.exception;

public class InvalidMobException extends RuntimeException {
	public InvalidMobException(String msg)
	{
		super(msg);
	}

}
