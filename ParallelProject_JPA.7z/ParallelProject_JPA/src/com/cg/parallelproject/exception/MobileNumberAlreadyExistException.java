package com.cg.parallelproject.exception;

public class MobileNumberAlreadyExistException extends Exception {

}
