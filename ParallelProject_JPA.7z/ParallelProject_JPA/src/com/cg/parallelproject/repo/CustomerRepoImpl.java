package com.cg.parallelproject.repo;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;


import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.util.JPAUtil;

public class CustomerRepoImpl implements CustomerRepo{

	EntityManager em=null;
	EntityTransaction entityTran=null;

	public CustomerRepoImpl() {
		em = JPAUtil.getEntityManager();
		entityTran=em.getTransaction();

	}

	@Override
	public boolean save(Customer customer) {
		Customer cust=findByOne(customer.getMobileNo());
		
		if(cust==null)
		{
			em.getTransaction().begin();
			em.persist(customer);
			em.getTransaction().commit();
		}
		else
		{
			return false;
		}
	
          return true;
	}

	@Override
	public Customer findByOne(String mobileNo) {
		Customer cust=em.find(Customer.class,mobileNo);	
		if(cust!= null) 
		   return cust;
		return null;
	}

	@Override
	public boolean update(String mobileNo, BigDecimal balance) {
		entityTran.begin();
		Customer cust=em.find(Customer.class, mobileNo);
				cust.getWallet().setBalance(balance);
				em.persist(cust);
				entityTran.commit();
		return false;
	}

}
