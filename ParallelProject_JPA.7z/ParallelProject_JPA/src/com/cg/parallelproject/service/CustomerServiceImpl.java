package com.cg.parallelproject.service;

import java.math.BigDecimal;


import com.cg.parallelproject.beans.Customer;
import com.cg.parallelproject.beans.Wallet;
import com.cg.parallelproject.exception.InvalidAmountPresentException;
import com.cg.parallelproject.exception.InvalidPhoneNumberException;
import com.cg.parallelproject.exception.MobileNumberAlreadyExistException;
import com.cg.parallelproject.repo.CustomerRepo;

public class CustomerServiceImpl implements CustomerService{

	static int count=1;
	CustomerRepo custRepo;
	
	
	public CustomerServiceImpl(CustomerRepo custRepo) {
		super();
		this.custRepo = custRepo;
	}

	@Override
	public Customer createAccount(String mobileNo, String name, BigDecimal initialBalance)throws  MobileNumberAlreadyExistException{
		Wallet wallet = new Wallet();
		wallet.setBalance(initialBalance);
		
		Customer customer = new Customer();
		customer.setMobileNo(mobileNo);
		customer.setName(name);
		customer.setWallet(wallet);
		
		if(custRepo.save(customer)) {
			return customer;
		}
		else {
			throw new MobileNumberAlreadyExistException();
		}
	}

	
	@Override
	public Customer showBalance(String mobileNo) throws InvalidPhoneNumberException {
		Customer customer=custRepo.findByOne(mobileNo);
		if(customer == null) {
			throw new InvalidPhoneNumberException();
		}
		custRepo.update(mobileNo, customer.getWallet().getBalance());						
		return customer;
		
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal Amount) throws InvalidPhoneNumberException {
		Customer customer=custRepo.findByOne(mobileNo);
		if(customer == null) {
			throw new InvalidPhoneNumberException();
		}
	customer.getWallet().setBalance(customer.getWallet().getBalance().add(Amount));
	custRepo.update(mobileNo, customer.getWallet().getBalance());
	
		return customer;
		
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal Amount) throws InvalidPhoneNumberException, InvalidAmountPresentException {
		
		if(validAmount(Amount))
			throw new InvalidAmountPresentException();
		Customer customer=custRepo.findByOne(mobileNo);
		if(customer == null) {
			throw new InvalidPhoneNumberException();
		}
		customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
		custRepo.update(mobileNo, customer.getWallet().getBalance());
		
		return customer;
		
	}

	@Override
 public boolean validAmount(BigDecimal Amount) throws InvalidAmountPresentException {
		if(!(Amount.compareTo(BigDecimal.ZERO)>0))
	  throw new InvalidAmountPresentException();
		return false;
	}

	@Override
	public Customer fundTransfer(String sourceMobNo, String Target, BigDecimal Amount) {
		Customer customer=custRepo.findByOne(sourceMobNo);
		Customer customer1=custRepo.findByOne(Target);
		customer1.getWallet().setBalance(customer1.getWallet().getBalance().add(Amount));
		
		//FUND GET RECIEVED TO OTHER ACCOUNT
		
		customer1.getWallet().setBalance(customer.getWallet().getBalance().subtract(Amount));
		custRepo.update(Target,customer.getWallet().getBalance());
		//FUND TRANSFER FROM FIRST ACCOUNT
		return customer1;
		
	}

	@Override
	public boolean repeatedAcc(String mobileNo) {
		Customer temp=null;
		temp=custRepo.findByOne(mobileNo);
		return true;
	}

}
